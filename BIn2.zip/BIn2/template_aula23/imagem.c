#include <stdio.h>
#include "imagem.h"
#include <stdlib.h>
#include <string.h>


struct Imagem
{
    int linhas,
        colunas,
        byteslidos;
    Tipo tipo;
    void *dados;
};
/**
 * @brief Função para ler uma imagem de um arquivo binário e aloca-la na memória.
 * A função também armazena o número de bytes lidos na estrutura Imagem.
 * @param path O caminho para o arquivo de imagem.
 * @return Um ponteiro para a imagem lida. Se houver erro (de leitura ou alocação de memória), a função imprime uma mensagem de erro e termina o programa.
 */
tImagem *LerImagem(const char *caminho)
{
    FILE *arq = fopen(caminho, "rb");

    if (arq == NULL) printf("PROBLEMA NA LEITURA DO ARQ %s\n" ,caminho);

    tImagem *img = (tImagem *)malloc(sizeof(tImagem));

    img->byteslidos = 0;

    img->byteslidos += fread(&img->linhas, sizeof(int), 1, arq);
    img->byteslidos += fread(&img->colunas, sizeof(int), 1, arq);
    img->byteslidos += fread(&img->tipo, sizeof(int), 1, arq);

    if (img->tipo == INT)
    {
        img->dados = malloc(sizeof(int) * img->linhas * img->colunas);
        img->byteslidos += fread(img->dados, sizeof(int), img->linhas * img->colunas, arq);
    }

    if (img->tipo == FLOAT)
    {
        img->dados = malloc(sizeof(float) * img->linhas * img->colunas);
        img->byteslidos += fread(img->dados, sizeof(float), img->linhas * img->colunas, arq);
    }

    fclose(arq);
    return img;
}

/**
 * @brief Função para destruir uma imagem.
 * @param img A imagem a ser destruída.
 */
void DestruirImagem(tImagem *img)
{
    if (img != NULL)
    {
        free(img->dados);
        free(img);
    }
}

/**
 * @brief Função para obter o número de bytes lidos de uma imagem.
 * @param img A imagem.
 * @return O número de bytes lidos.
 */
int ObterNumeroBytesLidos(tImagem *img)
{
    return img->byteslidos;
}

/**
 * @brief Função para imprimir uma imagem.
 * @param img A imagem.
 */
void ImprimirImagem(tImagem *img)
{
    for (int i = 0; i < (img->linhas * img->colunas); i++)
    {
        if (img->tipo == INT)
            printf("%d ",((int *)img->dados)[i]);
        else 
            printf("%.2f ",((float *)img->dados)[i]);
        if (i > 0 && (i%img->colunas - 1) == 0)
            printf("\n");
    }
}

/**
 * @brief Função para retornar o menor pixel da imagem.
 * @param img A imagem.
 */
void* menorPixelImagem(tImagem *img)
{

    void *menor;
    if (img->tipo == INT)
    {
        menor = malloc(sizeof(int));
        *((int *)menor) = 1000000;

        for (int i = 0; i < img->linhas * img->colunas; i++)
        {
            if ((*(int *)(img->dados + i)) < *((int *)menor))
            {
                *((int *)menor) = *((int *)img->dados + i);
            }
        }
    }

    if (img->tipo == FLOAT)
    {
        menor = malloc(sizeof(float));
        *((float *)menor) = 1000000;

        for (int i = 0; i < img->linhas * img->colunas; i++)
        {
            if ((*(float *)(img->dados + i)) < *((float *)menor))
            {
                *((float *)menor) = *((float *)img->dados + i);
            }
        }
    }

    return menor;
}

/**
 * @brief Função para retornar o maior pixel da imagem.
 * @param img A imagem.
 */
void* maiorPixelImagem(tImagem *img)
{
    void *maior;
    if (img->tipo == INT)
    {
        maior = malloc(sizeof(int)); //eh ponteiro
        *((int *)maior) = 1000000; //acessa conteudo

        for (int i = 0; i < img->linhas * img->colunas; i++)
        {
            if ((*(int *)(img->dados + i)) > *((int *)maior))
            {
                *((int *)maior) = *((int *)img->dados + i);
            }
        }
    }

    if (img->tipo == FLOAT)
    {
        maior = malloc(sizeof(float));
        *((float *)maior) = 1000000;

        for (int i = 0; i < img->linhas * img->colunas; i++)
        {
            if ((*(float *)(img->dados + i)) > *((float *)maior))
            {
                *((float *)maior) = *((float *)img->dados + i);
            }
        }
    }

    return maior;
}

/**
 * @brief Função para retornar a média dos pixels da imagem.
 * @param img A imagem.
 */
float mediaPixelImagem(tImagem *img)
{
    float media = 0.0;

    if (img->tipo == INT)
    {
        for (int i = 0; i < img->linhas * img->colunas; i++)
        {
            media += (float)*((int *)(img->dados + i)); //acessa conteudo e aritmetica de ponteiros
        }
    }

    else
        for (int i = 0; i < img->linhas * img->colunas; i++)
        {
            media += (float)*((float *)(img->dados + i));
        }
    
    return media /= (img->linhas * img->colunas);
}

/**
 * @brief Função para retornar o tipo dos pixels da imagem.
 * @param img A imagem.
 */
Tipo obtemTipoImagem(tImagem *img)
{
    return img->tipo;
}