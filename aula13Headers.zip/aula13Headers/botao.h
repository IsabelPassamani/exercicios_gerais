#ifndef _BOTAO_H
#define _BOTAO_H

#define MAX_TAM_TEXTO 30
#define CLICK 1
#define LONGO_CLICK 2
#define HOVER 3

typedef struct {
    char texto[MAX_TAM_TEXTO];
    int tamFonte;
    char corHex[7];
    int tipo;
    void (*executa)(void);
}Botao;

/*
Funcao que atualiza o texto de um botao criado.

@param b: Botao.
@param novoTexto: String com o texto a ser atualizado.
*/
void setarTexto(Botao *b, char *novoTexto);

/*
Funcao que o tamanho da fonte do texto de um botao criado.

@param b: Botao.
@param novoTamFonte: Inteiro com o novo valor da fonte do texto do botao.
*/
void setarTamFonte(Botao *b, int novoTamFonte);

/*
Funcao que atualiza a cor do texto de um botão criado.

@param b: Botao.
@param novoTexto: String com a cor do texto a ser atualizada.
*/
void setarCor(Botao *b, char *novaCor);

/*
Funcao que atualiza o tipo de um botão criado.

@param b: Botao.
@param novoTexto: Inteiro com o tipo do botao.
*/
void setarTipo(Botao *b, int novoTipo);

/*
@param texto: String com o texto do botao.
@param tamFonte: Inteiro com o tamanho da fonte do botao.
@param cor: Stri
@param idx: indice do botao a ser impresso.
*/
void desenhaBotao(Botao b, int idx);

#endif