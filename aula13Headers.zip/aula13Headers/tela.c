#include <stdio.h>
#include "tela.h"

/*
Funcao que cria uma tela de acordo com a altura e largura passadas por parametro

@param altura: Inteiro que define a altura da tela
@param largura: Inteiro que define a largura da tela

@return Tela: Tela criada
*/
Tela criarTela (int altura, int largura)
{
    Tela t;

    t.altura = altura;
    t.largura = largura;
    t.qntBotoes = 0;

    return t;
}

/*
Funcao que adiciona um novo botao a tela

@param t: Tela a ser atualizada com o novo botao
@param b: Botao a ser adicionado a tela

@return Tela: Tela criada
*/
void registraBotaoTela(Tela *t, Botao b)
{
    t->botoes[t->qntBotoes] = b;
    t->qntBotoes++;
}

/*
Funcao que desenha a tela (desenha todos os botões que foram registrados).

@param t: Tela a ser desenhada (e seus respectivos botoes)
*/
void desenhaTela (Tela *t)
{
    //desenha de acordo com a qntd de botoes com desenhabotao
}

/*
Funcao que aguarda um evento de clique (simulado pela leitura do teclado). 
O clique é simulado pela seleção de uma das opções dos botões.
Exemplo - clicar no primeiro botão significa escolher a opção "1" pelo terminal. 

@param t: Tela criada que aguarda um evento para executar uma funcao de Callback
*/
void ouvidorEventosTela(Tela t)
{
    int opcao;
    scanf("%d" ,opcao);
    
}