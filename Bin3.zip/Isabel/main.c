#include <stdio.h>
#include "histograma.h"

int main()
{
    char path[1024];
    int nIntervalos;

    scanf("%s" ,path);
    scanf("%d" ,&nIntervalos);

    Imagem *img = LerImagem(path);
    Histograma *h = CalcularHistograma(img, nIntervalos);
    MostrarHistograma(h);
    DestruirHistograma(h);
    DestruirImagem(h);

    return 0;
}