#include "histograma.h"
#include <stdio.h>
#include <stdlib.h>

struct tHistograma
{
    int *contagens;
    int tam_bucket, nIntervalos;
};


Histograma *CalcularHistograma(Imagem *img, int nIntervalos)
{
    int val;

    Histograma *h = (Histograma *)malloc(sizeof(Histograma));
    h->nIntervalos = nIntervalos;
    h->tam_bucket = 256 / nIntervalos;

    if (256 % nIntervalos != 0)
    {
        h->tam_bucket++;
    }

    h->contagens = (int *)calloc(nIntervalos, sizeof(int));

    for (int i = 0; i < ObterAlturaImagem(img) * ObterLarguraImagem(img); i++)
    {
        if (ObterTipoImagem(img) == INT)
        {
            val = ((int *)ObterDadosImagem(img))[i];
        }
        else
        {
            val = ((float *)ObterDadosImagem(img))[i] * 255;
        }

        h->contagens[(val/h->tam_bucket)]++;
    }

    return h;
}

void MostrarHistograma(Histograma *histograma)
{
    for (int i = 0; i < histograma->nIntervalos; i++)
    {
        printf("[%d, %d): %d\n" ,i*histograma->tam_bucket, (i+1) * histograma->tam_bucket, histograma->contagens[i]);
    }
}

void DestruirHistograma(Histograma *histograma)
{
    if (histograma != NULL)
    {
        free(histograma->contagens);
        free(histograma);
    }
}

