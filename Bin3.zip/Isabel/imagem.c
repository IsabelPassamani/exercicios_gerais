#include "imagem.h"
#include <stdio.h>
#Include <stdlib.h>
/**
 * @brief Estrutura para representar uma imagem.
 */

/*
Dois inteiros de 4 bytes contendo o número de linhas M e de colunas N da imagem
Um inteiro de 4 bytes representando o tipo que pode ser 0 ou 1, sendo que 0 representa
FLOAT e 1 representa INT.
M x N valores dos tipos INT ou FLOAT, dependendo do campo anterior, cada um com 4
bytes, representando as cores dos pixels. Os dados estão em formato linearizado, i.e., as
linhas da matriz foram colocadas uma na frente da outra de forma que a estrutura
resultante tenha a forma de um vetor com 1 linha e M * N colunas. Se a imagem for do tipo
INT, os valores dos pixels estarão entre 0 e 255, sendo que 0 representa preto e 255
representa branco. Se a imagem for do tipo FLOAT, os valores estarão entre 0.0 e 1.0,
sendo que 0.0 representa preto e 1.0 representa branco. Em ambos os casos, valores
intermediários entre os limites mínimo e máximo são tons de cinza.
*/
struct Imagem
{   int nLinhas;
    int nColunas;
    Tipo tipoVar;
    void *cores;
}

/**
 * @brief Função para ler uma imagem de um arquivo binário e aloca-la na memória.
 * @param path O caminho para o arquivo de imagem.
 * @return Um ponteiro para a imagem lida. Se houver erro (de leitura ou alocação de memória), a função imprime uma mensagem de erro e termina o programa.
 */
Imagem *LerImagem(const char *caminho)
{
    FILE arquivo = *fopen(caminho, 'rb');

    if (fopen != NULL)
    {
        Imagem *img = (Imagem *)malloc(sizeof(Imagem));

        if (img->tipoVar == INT)
        {

        }
    }
}
/**
 * @brief Função para destruir uma imagem.
 * @param img A imagem a ser destruída.
 */
void DestruirImagem(Imagem *img)
{
    free(img->cores);
    free(img);
}

/**
 * @brief Função para obter a altura de uma imagem.
 * @param img A imagem.
 * @return A altura da imagem.
 */
int ObterAlturaImagem(Imagem *img)
{
    return img->nLinhas;
}

/**
 * @brief Função para obter a largura de uma imagem.
 * @param img A imagem.
 * @return A largura da imagem.
 */
int ObterLarguraImagem(Imagem *img)
{
    return img->nColunas;
}

/**
 * @brief Função para obter o tipo de uma imagem.
 * @param img A imagem.
 * @return O tipo da imagem.
 */
Tipo ObterTipoImagem(Imagem *img)
{
    return img.tipoVar;
}

/**
 * @brief Função para obter os dados de uma imagem.
 * @param img A imagem.
 * @return Um ponteiro para os dados da imagem.
 */
void *ObterDadosImagem(Imagem *img)
{
    return img.cores;
}
